const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json()); // ✅ must have parentheses!

app.post("/submit", (req, res) => {
  console.log("Received data:", req.body);
  res.json({ message: "Data received successfully", data: req.body });
});

app.listen(5000, () => {
  console.log("✅ Server running on port 5000");
});