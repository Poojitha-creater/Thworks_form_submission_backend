---

## ⚙ *Backend README (Express Server)*

markdown
# Backend - Form Submission API

This is the **backend** part of the project built using **Node.js and Express**.  
It receives form data from the frontend and logs it in the terminal.

---

### 🚀 Features
- Express server running on port 5000
- Accepts POST requests from frontend at `/submit`
- Handles JSON data using `express.json()`
- Supports CORS for cross-origin requests

---

### 🛠 Tech Stack
- Node.js
- Express.js
- CORS middleware

---

### ⚙ Setup & Run

1. Install dependencies  
   bash
   npm install express cors

2.Start the server 
node index.js 

3.The backend runs on:
https:localhost:5000 

🧠 API Endpoint

POST /submit
Accepts form data in JSON format:

{
  "name": "Poojitha",
  "email": "poojitha@example.com",
  "phone": "9876543210"
}

Response:

{
  "message": "Data received successfully!"
}


---

✅ Example Log

Server running on port 5000
Received data: { name: 'Poojitha', email: 'poojitha@example.com', phone: '9876543210' }





